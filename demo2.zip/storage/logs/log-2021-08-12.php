<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-12 00:13:38 --> Could not find the language line "service_and_barber"
ERROR - 2021-08-12 16:52:27 --> Could not find the language line "service_and_barber"
ERROR - 2021-08-12 16:52:49 --> Could not find the language line "service_and_barber"
ERROR - 2021-08-12 23:48:36 --> Could not find the language line "service_and_barber"
