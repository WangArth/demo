<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-18 20:40:40 --> Could not find the language line "service_and_barber"
ERROR - 2021-08-18 20:46:19 --> Could not find the language line "service_and_barber"
ERROR - 2021-08-18 20:46:20 --> Could not find the language line "service_and_barber"
