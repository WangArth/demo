Swal.fire({
  title: '<strong><u>Instrucciones </u></strong>',
  icon: 'info',
  html:
    
    '<br><p> <b>Agenda un cita por persona  </b> </p>' + 
    '<br> <h3> Descanso de Barberos</h3> ' +
    '<br> <p> EST. 1 MIGUEL | LUNES</p>' +
     '<br> <p> EST.  ANGEL | DOMINGO</p>' +
     '<br> <p> EST. 3 EDWIN | JUEVES</p>' +
     '<br> <p>EST. 4 ALEX | MARTES</p>' +
     '<br> <p> EST. 5 ALEJANDRO V. | MIERCOLES</p>' ,
  showCloseButton: false,
  focusConfirm: false,
  confirmButtonColor: "#ffd700",
  confirmButtonText:
    '<i class="fa fa-thumbs-up"></i> ¡Genial!',
  confirmButtonAriaLabel: 'Thumbs up, great!'
})





