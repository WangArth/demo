 function loadPage(){
     var frame = $('#frame');
     var url = 'https://clientedigital.com.mx/zonabigotes/ver.php';
     frame.attr('src',url).show();
 }